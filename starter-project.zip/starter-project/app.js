import express from 'express';
import { client, connection } from './database.js';
const app = express();

app.set('view engine', 'ejs');

let server;
connection.then(()=>{
  console.log("Successful connection to database!");
  server = app.listen(3000, ()=>console.log('Server listening.'));
})
.catch(e=>console.error(e));

const database = client.db('assignment-5');

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }))

app.get('/', (req,res)=>{
    res.render('index', { message: "" });
});

app.post('/tv-shows', (req,res)=>{
    // TODO
});

app.get('/tv-shows', (req,res)=>{
    // TODO
});